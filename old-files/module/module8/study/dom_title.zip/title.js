// TODO: get the title of the page
	
// TODO: create a new string, which repeats the title 5 times

// TODO: update the title of the page
